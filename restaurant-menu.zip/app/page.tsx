import RestaurantMenu from "@/components/restaurant-menu"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <RestaurantMenu />
    </main>
  )
}
